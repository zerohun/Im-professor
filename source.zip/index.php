<?php
  require_once "upper.php";
?>
		<div class="section" id="about">
			<img src="image/content1.png" alt="사이트소개"/>
      </div>
<!--
		<div class="section" id="rank">
				<h1><img src="image/best5.png" alt="best5"/></h1>
				<div class="list">
				</div>
      </div>

-->
			
<?php
  require_once "beneath.php";
?>
