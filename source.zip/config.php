<?php
  require_once "model.php";
  $db_hostname = 'localhost';
  $db_database = 'TEST';
  $db_username = 'root';
  $db_password = '13245';
  $db_admin = "admin";
  
  $db_con = mysql_connect($db_hostname, $db_username, $db_password);
  if (!$db_con) die("Unable to connect to MySQL: " . mysql_error());

  mysql_select_db($db_database, $db_con) or die("Unable to select database:". mysql_error());
  mysql_query("SET NAMES 'utf8'");


?>

