<?php
require 'model.php';
class User extends Model{

}
?>
