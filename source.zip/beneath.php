  </div>
	<div id="footer">
	  <p>2011 컴퓨터공학과 웹프로그래밍 C반 8조 최영훈, 오세도, 서수경, 이자연</p>
	  <p>Copyright © 나는교수다. All rights reserved.</p>
	</div>
</div>
</body>
</html>
